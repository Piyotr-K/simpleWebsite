package Unit5;

public class driver {
    
    public static void main(String[] args) {
        Coordinate3D t = new Coordinate3D(0,4,5);
        Coordinate3D t1 = new Coordinate3D(0,4,5);

        for (int j = 0; j < 300; j++)
        {
            int i = (int) (Math.random() * 21) + 5; // 5 <= x <= 25
            System.out.println(i);
        }
    }

    public static void weee(Double d)
    {
        d = 5.6;
    }
}
