package Unit5;

public class driver {
    
    public static void main(String[] args) {
        Coordinate3D t = new Coordinate3D(0,4,5);
        Coordinate3D t1 = new Coordinate3D(0,4,5);

        // System.out.println(t.equals(t1));

        // System.out.println(t);
        // System.out.println("Lellelelelle".compareTo("Lel"));
        Integer tmp = 3;
        Integer tmp2 = 5;
        System.out.println(tmp < tmp2);
    }

    public static void weee(Double d)
    {
        d = 5.6;
    }
}
