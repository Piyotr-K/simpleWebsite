package Unit5;

public class Coordinate3D {
    
    private int x;
    private int y;
    private int z;

    public Coordinate3D(int _x, int _y, int _z)
    {
        x = _x;
        y = _y;
        z = _z;
    }

    public String toString()
    {
        return "{x: " + x + ", y: " + y + ", z: " + z + "}";
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public int getZ() { return z; }

    public boolean equals(Coordinate3D c)
    {
        return (this.getX() == c.getX() &&
                this.getY() == c.getY() &&
                this.getZ() == c.getZ());
    }
}
