import java.util.Scanner;

public class driver {

    static Scanner s = new Scanner(System.in);
    
    public static void main(String[] args) {
        getSum();
    }

    public static void stackWords()
    {
        String word = s.nextLine();
        if (word.equals("."))
            System.out.println();
        else
            stackWords();
        System.out.println(word);
    }

    public static void stackOverflowEx()
    {
        try 
        {
            randomRecursion();
        }
        catch (StackOverflowError e)
        {
            System.out.println(e.toString());
        }
    }

    public static void randomRecursion()
    {
        randomRecursion();
    }

    private static void getSum()
    {
        int n;
        System.out.println("Enter an integer greater than 0: ");
        n = s.nextInt();
        if (n > 0)
            System.out.println(sum(n));
        else
        {
            throw new IllegalArgumentException("Error: n must be positive");
        }
    }

    private static int sum(int n)
    {
        if (n == 1)
            return 1;
        else
            return n + sum(n - 1);
    }
}
