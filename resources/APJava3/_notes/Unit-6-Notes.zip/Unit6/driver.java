package Unit6;

public class driver {
    
    public static void main(String[] args) {
        boolean something = true;
        if (something || 1 / 0 < 1)
        {
            System.out.println("hee");
        }

        // Math m = new Math();
    }

    public static void beegTask()
    {
        smallerTask1();
        // Thing2
        // Thing3
    }

    public static void smallerTask1()
    {
        // Thing1
    }

    public static void displayMenu()
    {
        while (true)
        {
            menu();
        }
    }

    public static void menu()
    {
        String s = ""; // Scanner
        if (s.equals("add"))
        {
            add();
        }
        else if (s.equals("Delete"))
        {
            // thicc code to delete
            // thicc code to delete
            // thicc code to delete
            // thicc code to delete
            // thicc code to delete
            // thicc code to delete
            // thicc code to delete
            // thicc code to delete
            // thicc code to delete
            // thicc code to delete
            // thicc code to delete
        }
    }

    public static void add()
    {
        // thicc code to add
        // thicc code to add
        // thicc code to add
        // thicc code to add
        // thicc code to add
        // thicc code to add
        // thicc code to add
        // thicc code to add
        // thicc code to add
        // thicc code to add
    }

    public static void addStub()
    {
        System.out.println("Add stub called.");
    }
}
