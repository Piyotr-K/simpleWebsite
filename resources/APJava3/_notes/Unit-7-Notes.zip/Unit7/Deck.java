public class Deck {
    
    private int size = 52;
    private int[] cards = new int[size];

    public Deck()
    {
        for (int i = 0; i < size; i++)
        {
            cards[i] = i + 1;
        }
    }

    public void shuffle()
    {
        for (int i = 0; i < size; i++)
        {
            cards[i] = 1;
        }
    }
}
