import java.util.ArrayList;

public class driver {

    public static void main(String[] args) {
        ex7();
    }

    public static void ex1()
    {
        int[] arr = {1, 9, 1, 2, 2, 4};
        printArr(arr);
        swap(arr);
        printArr(arr);
    }

    public static void swap(int[] a)
    {
        int temp = a[0];
        a[0] = a[1];
        a[1] = temp;
    }

    public static void printArr(int[] a)
    {
        for (int num : a) System.out.print(num + " ");
        System.out.println();
    }

    public static void print2DArr(int[][] a)
    {
        String out = "";
        for (int[] row : a)
        {
            for (int num : row)
                out += num + "\t";
            out += "\n";
        }
        System.out.println(out);
    }

    public static void ex2()
    {
        AllDecks a = new AllDecks();
    }

    public static void ex3()
    {
        ArrayList<Integer> l = new ArrayList<Integer>();
        ArrayList<Deck> d1 = new ArrayList<Deck>();

        l.add(5);

        int num = l.get(0) + 5; // auto-unboxed here
        // d1.add(5);
    }

    public static void ex4()
    {
        // ConcurrentModificationException
        ArrayList<Integer> list = new ArrayList<Integer>();
        for (int i = 0; i < 500; i++)
            list.add((int) (Math.random() * 101));

        for (Integer num : list)
            if (num < 0)
                list.add(0);
    }

    public static void ex5()
    {
        // INITIALIZER LIST
        int[][] mat = {
            {1, 2, 3, 4, 5},
            {6, 7, 8, 9, 10},
            {11, 12, 13, 14, 15},
        };

        int sum = 0;
        // normal for loop method:
        // for (int row = 0; row < mat.length; row++)
        //     for (int col = 0; col < mat[row].length; col++)
        //         sum += mat[row][col];

        // Enhanced for-loop method:
        for (int[] row : mat)
            for (int num : row)
                sum += num;
        
        System.out.println(sum);

    }

    public static void ex6()
    {
        // INITIALIZER LIST
        int[][] mat = {
            {1, 2, 3, 4, 5},
            {6, 7, 8, 9, 10},
            {11, 12, 13, 14, 15},
        };

        // Increase values in the second row by 10
        for (int col = 0; col < mat[1].length; col++)
            mat[1][col] += 10;
        
        // NOTE: Enhanced for loop no work
        // for (int num : mat[1])
        //     num += 10;
        
        print2DArr(mat);
    }

    public static void ex7()
    {
        // INITIALIZER LIST
        int[][] mat = {
            {1, 2, 3, 4},
            {5, 6, 7, 8},
            {9, 10, 11, 12},
            {13, 14, 15, 16}
        };

        System.out.println("Major-Diagonal");
        // A Major-diagonal is all the elements in the diagonal
        // in the direction of topLeft to botRight
        // Print out da [1][1], [2][2], [3][3]
        for (int i = 0; i < mat.length; i++)
            System.out.println(mat[i][i]);
        
        System.out.println("Minor-Diagonal");
        // A Minor-diagonal is all the elements in the diagonal
        // in the direction of botLeft to topRight
        // Print out da [0][3], [1][2], [2][1]
        for (int i = 0; i < mat.length; i++)
            System.out.println(mat[i][mat.length - i - 1]);
    }
}