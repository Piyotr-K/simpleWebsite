public class driver {

    public static void main(String[] args) {
        ex1();
    }

    public static void ex1()
    {
        int[] arr = {1, 9, 1, 2, 2, 4};
        printArr(arr);
        swap(arr);
        printArr(arr);
    }

    public static void swap(int[] a)
    {
        int temp = a[0];
        a[0] = a[1];
        a[1] = temp;
    }

    public static void printArr(int[] a)
    {
        for (int num : a) System.out.print(num + " ");
        System.out.println();
    }

    public static void ex2()
    {
        AllDecks a = new AllDecks();
    }
}