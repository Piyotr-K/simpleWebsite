import java.util.ArrayList;

public class driver {

    public static void main(String[] args) {
        ex4();
    }

    public static void ex1()
    {
        int[] arr = {1, 9, 1, 2, 2, 4};
        printArr(arr);
        swap(arr);
        printArr(arr);
    }

    public static void swap(int[] a)
    {
        int temp = a[0];
        a[0] = a[1];
        a[1] = temp;
    }

    public static void printArr(int[] a)
    {
        for (int num : a) System.out.print(num + " ");
        System.out.println();
    }

    public static void ex2()
    {
        AllDecks a = new AllDecks();
    }

    public static void ex3()
    {
        ArrayList<Integer> l = new ArrayList<Integer>();
        ArrayList<Deck> d1 = new ArrayList<Deck>();

        l.add(5);

        int num = l.get(0) + 5; // auto-unboxed here
        // d1.add(5);
    }

    public static void ex4()
    {
        // ConcurrentModificationException
        ArrayList<Integer> list = new ArrayList<Integer>();
        for (int i = 0; i < 500; i++)
            list.add((int) (Math.random() * 101));

        for (Integer num : list)
            if (num < 0)
                list.add(0);
    }
}