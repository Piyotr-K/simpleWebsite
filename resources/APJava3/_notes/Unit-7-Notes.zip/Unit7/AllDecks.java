public class AllDecks {
    
    private int NUMDECKS = 500;
    private Deck[] allDecks = new Deck[NUMDECKS];

    public AllDecks()
    {
        for (int i = 0; i < NUMDECKS; i++)
        {
            allDecks[i] = new Deck();
        }
    }

    public void shuffleAll()
    {
        for (Deck d : allDecks)
            d.shuffle();
    }
}
