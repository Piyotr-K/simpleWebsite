public class Unit3 {

    public static void main(String[] args)
    {
        int time;
        Unit3Classes uc1 = new Unit3Classes();
        Unit3Classes uc2 = new Unit3Classes();

        System.out.println("Before Swap:");
        System.out.println(uc1);
        System.out.println(uc2);
        System.out.println();
        uc1.swapperoni(uc1, uc2);
        System.out.println("After Swap: ");
        System.out.println(uc1);
        System.out.println(uc2);

        // Unit3Classes uc3 = null;
        // System.out.println(uc1.getTime());
        // referal(uc1, uc3);
        // System.out.println(uc1.getTime());

        // System.out.println(Unit3Classes.COUNTER);
        // System.out.println(uc2.getTime());
        // System.out.println(uc2.getHee());
    }

    public static void referal(Unit3Classes u1, Unit3Classes u2)
    {
        u2 = u1;
        u2.mutateTime(6);
    }
}
