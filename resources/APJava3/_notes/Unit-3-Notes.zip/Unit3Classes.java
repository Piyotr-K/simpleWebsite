public class Unit3Classes {
    
    public static int COUNTER = 0;
    public static final int NICE = 10;
    private int time;
    private String hee;

    public Unit3Classes()
    {}

    public static int power(int x, int y)
    {
        int temp = x;
        for (int i = 0; i < y; i++)
        {
            x *= temp;
        }
        return x;
    }

    public void swapperoni(Unit3Classes c1, Unit3Classes c2)
    {
        c1 = c2;
    }

    public void mutateTime(int num)
    {
        this.time += num;
    }

    public int selectiveTime(int num)
    {
        if (num > 3)
        {
            return time + 3;
        }
        return time;
    }

    public void addTime(int t)
    {
        this.time += t;
    }

    public void setTime(int t)
    {
        this.time = t;
    }

    public int getTime()
    {
        return this.time;
    }

    public String getHee()
    {
        return this.hee;
    }

}
