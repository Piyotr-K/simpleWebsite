public class Unit4 {
    
    public static void main(String[] args) {
        Unit4Inheritance uc = new Unit4SubClass(6);
        Unit4SubClass uc2 = new Unit4SubClass(4);
        uc2.transfer(uc);
    }
}
