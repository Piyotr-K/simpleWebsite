package Unit4;
public class Unit4 {
    
    public static void main(String[] args) {
        Unit4Inheritance uc = new Unit4SubClass();
        Unit4SubClass uc2 = new Unit4SubClass();
        Unit4Inheritance uc3 = new Temp();
        System.out.println(((Unit4SubClass) uc).getZ());
        // whatever(uc3);
    }

    public static void whatever(Temp p)
    {

    }
}
