package Unit4;
public class Temp extends Unit4Inheritance {
    
}
