public class Unit4SubClass extends Unit4Inheritance {
    
    public Unit4SubClass()
    {
        super();
    }

    public Unit4SubClass(int i)
    {
        super(i);
    }

    public void idklol()
    {
        System.out.println("Sub class");
    }

    public void random()
    {
        System.out.println(y);
        System.out.println(super.getX());
    }
}
