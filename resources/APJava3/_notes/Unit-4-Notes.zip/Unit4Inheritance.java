public class Unit4Inheritance {
    
    private int x;
    public int y;

    public Unit4Inheritance()
    {
        this.x = 4;
        this.y = 5;
    }

    public Unit4Inheritance(int i)
    {
        this.x = i;
        this.y = 7;
    }

    public void idklol()
    {
        System.out.println("Super Class");
    }

    public void transfer(Unit4Inheritance u4)
    {
        idklol();
    }

    public int getX()
    {
        return this.x;
    }

    public int getY()
    {
        return this.y;
    }
}
