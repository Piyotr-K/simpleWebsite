public class Unit2 {
    
    public static void main(String[] args)
    {
        // String class = "nice"; // cannot use reserved words
        // String 9hee = "hee"; // cannot start with a digit

        // int x, y = 0, z; // Single line delcaration
        // int x, h = "nice"; // no mix-and-match types

        // int x, y, z = 0; // = 0 only applies to y
        // System.out.println(z);

        // System.out.println(3.0 / 4.0);
        // shortCircuit();

        System.out.print("Hot");
        System.out.println("Dog");
    }

    public static void shortCircuit()
    {
        int[] a1 = {};
        if ((a1.length >= 1) && (a1[0] == a1[a1.length - 1]))
        {
            // something
            System.out.println("Success");
        }
    }
}
