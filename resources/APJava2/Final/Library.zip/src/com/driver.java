package src.com;

public class driver {

    public static void main(String[] args)
    {
        Library lib = new Library("VPL");
        lib.add(new Book("Moby Dick", "Herman Melville", "1412", 20));
        lib.add(new Book("Grafield", "Jim Davis", "1992", 15));
        lib.add(new Book("( ͡❛ ⏥ ͡❛)", "Jonathan Gong", "2021", 0));

        System.out.println(lib.listAll());
    }
}
