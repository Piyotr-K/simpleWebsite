package src.com;

public abstract class Media {

    private String title;
    private String author;
    private String date;

    public Media(String title, String author, String date)
    {
        this.title = title;
        this.author = author;
        this.date = date;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getTitle()
    {
        return this.title;
    }

    public void setAuthor(String author)
    {
        this.author = author;
    }

    public String getAuthor()
    {
        return this.author;
    }

    public void setDate(String date)
    {
        this.date = date;
    }

    public String getDate()
    {
        return date;
    }
    
}
