package src.com;

public class AudioClip extends DigitalMedia {

    public AudioClip(String title, String author, String date,
                        int avgDecibels, int duration, int framesPerSecond)
    {
        super(title, author, date, duration, avgDecibels);
    }
}
