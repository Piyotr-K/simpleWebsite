package src.com;

import java.util.ArrayList;

public class Library {

    private String name;
    private ArrayList<Media> allItems;

    public Library(String name)
    {
        this.name = name;
        allItems = new ArrayList<Media>();
    }

    public void add(Media item)
    {
        allItems.add(item);
    }

    public void remove(Media item)
    {
        allItems.remove(item);
    }

    public String listAll()
    {
        String out = "";
        for (Media m : allItems)
        {
            out += m.toString() + "\n";
        }
        return out;
    }

}
