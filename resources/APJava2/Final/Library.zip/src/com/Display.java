package src.com;

public class Display {
    // Show a menu and take input and what not

    Library l;

    public Display(String libraryName)
    {
        l = new Library(libraryName);
    }

    public void displayAll()
    {
        System.out.println(l.listAll());
    }
}
