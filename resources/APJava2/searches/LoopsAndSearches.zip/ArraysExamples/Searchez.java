package src.ArraysExamples;

public class Searchez {
    
    // Sequential Search, fancy name for brute forcing
    // a search
    public int getIndexOfItem(int[] arr, int num)
    {
        for(int i = 0; i < arr.length; i++)
        {
            if (arr[i] == num)
            {
                return i;
            }
        }
        return -1; // Can't find it
    }

    public int getIdx(int[] arr, int num)
    {
        int low = 0;
        int high = arr.length - 1;
        while (low <= high)
        {
            int mid = (high + low) / 2;
            if (num < arr[mid])
            {
                high = mid - 1; // Get rid of the back half of the array
            }
            else if (num > arr[mid])
            {
                low = mid + 1; // Get rid of the front half of the array
            }
            else return mid;
        }
        return -1;
    }
}
