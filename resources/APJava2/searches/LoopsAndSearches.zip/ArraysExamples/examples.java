package src.ArraysExamples;

public class examples<T> {

    public static void main(String[] args)
    {
        // stuff();
        // List<Integer> arr1 = new ArrayList<>();
        // arr1.add(34);
        // arr1.add(5);
        searchStuff();
    }

    public static void passBy()
    {
        // pass by value
        int test = 5;
        changeInt(test);
        System.out.println(test);

        // pass by reference
        int[] arr2 = {1, 2, 3};
        changeIntArr(arr2);
        printArr(arr2);
    }

    public static void changeInt(int x)
    {
        x += 5;
    }

    public static void changeIntArr(int[] x)
    {
        x[0] += 5;
    }

    public static void searchStuff()
    {
        int[] tmp = {1, 6, 7, 3, 5, 10, 9};
        int[] tmp2 = {1, 2, 4, 7, 9, 10, 12, 14, 17};
        int numToFind = 7;
        Searchez s = new Searchez();

        int result = s.getIndexOfItem(tmp, numToFind);
        System.out.println(result);

        result = s.getIdx(tmp2, numToFind);
        System.out.println(result);
    }


    public static void printArr(int[] arr)
    {
        for (int i = 0; i < arr.length; i++)
        {
            System.out.print(arr[i] + ",");
        }
        System.out.println();
    }

    public static void stuff()
    {
        int[] arr1 = {1, 2, 3, 4, 5};
        int[] tmp = new int[arr1.length * 2];

        System.out.println("Array 1 before expand");
        printArr(arr1);

        for (int i = 0; i < arr1.length; i++)
        {
            tmp[i] = arr1[i];
        }

        arr1 = tmp;
        System.out.println("Array 1 after expand");
        printArr(arr1);

        arr1[5] = 6;
        arr1[6] = 7;
        System.out.println("Array 1 after expand and add moar");
        printArr(arr1);
        System.out.println(arr1.length);
    }
}