package src.basic;

public class SelectionSort {

    public static void sort(int[] arr)
    {
        int i, j;

        for (j = 0; j < arr.length; j++)
        {
            int minIndex = j;

            for (i = j + 1; i < arr.length; i++)
                if (arr[i] < arr[minIndex])
                    // update the index of the smallest num
                    // if the new one is smaller
                    minIndex = i;
            
            if (minIndex != j)
                swap(arr, j, minIndex);
        }
    }

    public static void swap(int[] arr, int idx1, int idx2) // {1, 2} -> {2, 1}
    {
        int tmp = arr[idx1];
        arr[idx1] = arr[idx2];
        arr[idx2] = tmp;
    }
}
