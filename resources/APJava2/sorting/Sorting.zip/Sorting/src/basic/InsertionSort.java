package src.basic;

public class InsertionSort {
    
    public static void sort(int[] a)
    {
        int i, j;

        for (i = 1; i < a.length; i++)
        {
            int key = a[i];
            for (j = i - 1; j >= 0 && a[j] > key; j--)
                a[j + 1] = a[j];
            a[j + 1] = key;
        }
    }
}
