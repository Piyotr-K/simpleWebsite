package src.basic;

public class driver {
    
    public static void main(String[] args) {
        int[] arr1 = {6, 7, 1, 2, 6, 4, 3, 5, 10, 35};
        printArr(arr1);
        InsertionSort.sort(arr1);
        printArr(arr1);
        // recurse(5);
        // System.out.println(fibonacci(10));
    }

    public static void printArr(int[] a)
    {
        for (int n : a)
            System.out.print(n + " ");
        System.out.println();
    }

    public static int recurse(int a)
    {
        if (a == 0)
            return 0;
        System.out.println("Hello");
        return recurse(a - 1);
    }

    public static int fibonacci(int n)
    {
        if (n == 0)
            return 0;
        if (n == 1)
            return 1;
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}
