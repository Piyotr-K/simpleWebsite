package src.medium;

public class driver {
    
    public static void main(String[] args) {
        int[] arr1 = {6, 7, 1, 2, 6, 4, 3, 5, 10, 35};
        printArr(arr1);
        arr1 = MergeSort.sort(arr1);
        printArr(arr1);
    }

    public static void printArr(int[] a)
    {
        for (int n : a)
            System.out.print(n + " ");
        System.out.println();
    }
}
