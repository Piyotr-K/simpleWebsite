package Classes1;

public class Dog {

    // Properties
    private String name;
    private String breed;
    private int age;

    public Dog()
    {
        this("Default Name", "Default Breed", 0);
    }

    // Overloading constructor
    // Means: same name but different number of parameters or
    // different parameters
    public Dog(String name, String breed)
    {
        this.name = name;
        this.breed = breed;
        age = 0; // 0 by default
    }

    // Constructor
    public Dog(String name, String breed, int age)
    {
        this.name = name;
        this.breed = breed;

        if (checkInfo(age)) this.age = age;
        else this.age = 0;

        System.out.println("Dog materializing...");
        System.out.println("Done");
    }

    // Behaviours (Methods)
    public void woof()
    {
        System.out.println("Woof");
    }

    public void whimper()
    {
        System.out.println("Whimper");
    }

    public void bark()
    {
        System.out.println(this.name + " the dog barks!");
    }

    private boolean checkInfo(int numbers)
    {
        if (numbers > 0 && numbers < 40)
            return true;
        return false;
    }

    // Getter
    // Ex of an Accessor
    public String getName()
    {
        return name;
    }

    // Setter
    // Ex of a Mutator
    public void setName(String name)
    {
        this.name = name;
    }
}
