package Classes1;

public class driver {
    
    public static void main(String[] args) {
        Dog d1 = new Dog("Coggy", "Corgi", 5);
        Dog d2 = new Dog("Snoopy", "Beagle", 7);
        Dog d3 = new Dog();
        d1.setName("Rhys");
        System.out.println(d1.getName());
        // d1.bark();
        // d2.bark();
        // d3.bark();
    }
}
