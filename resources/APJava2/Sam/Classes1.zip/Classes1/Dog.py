class Dog():

    def __init__(self):
        self.name = ""
        self.breed = ""
        self.age = 0
        print("Materializing Dog...")
        print("Done")

    def woof(self):
        print("Woof")
    
    def whimper(self):
        print("whimper")