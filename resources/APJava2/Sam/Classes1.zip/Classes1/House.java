package Classes1;

public class House {
    
    // Fields for every house
    public int floors;
    public int rooms;
    public String address;

    public House(int _floors, int _rooms, String _address)
    {
        floors = _floors;
        rooms = _rooms;
        address = _address;
    }
}
