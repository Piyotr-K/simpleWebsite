package Wrapper;

public class Landcraft {

    private double weight;

    public Landcraft(double _weight)
    {
        weight = _weight;
    }
    
    public double getWeight() { return weight; }

    public String toString()
    {
        return "Landcraft weight: " + weight;
    }

    public boolean equals(Object other)
    {
        if (this == other) return true; // In the case that you're comparing the object to itself
        // In the case that the other is nothing or you're comparing two serparate things eg. comparing Animal to a pencil
        if (other == null || getClass() != other.getClass()) return false;

        // Upcasting to access the private variable "weight"
        Landcraft tmp = (Landcraft) other;

        if (weight == tmp.weight) return true;
        return false;
    }
}
