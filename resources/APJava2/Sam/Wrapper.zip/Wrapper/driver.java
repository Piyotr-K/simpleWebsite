package Wrapper;

public class driver {
    
    public static void main(String[] args) {
        p7();
    }

    public static void p1()
    {
        // Java takes a shortcut when you create 2 objects with the same properties
        String s = "nice";
        String s2 = new String("nice");

        System.out.println(s.equals(s2));
    }

    public static void p2()
    {
        Tank t1 = new Tank(0, 2000, "Military");
        Tank t2 = new Tank(0, 2000, "Military");

        System.out.println(t1.equals(t2));
    }

    public static void p3()
    {
        // Java based on ASCII Table
        // Capital letters come before lower case letters
        // Shorter words come before longer words eg. word & words > word comes first
        String s = "able";
        String s2 = new String("ableo"); // s.compareTo(s2) > -1

        // Compare string s to s2 lexicographically (dictionary order)
        System.out.println(s.compareTo(s2));
        // System.out.println(s2.compareTo(s));
    }

    public static void p4()
    {
        String s = "BigHugeLargeElephantine";
        // substring(startIndex, endIndex);
        // From startIndex to endIndex - 1
        // *REMEMBER endIndex - 1
        // String tmp = s.substring(0, 3);
        // System.out.println(tmp);

        // substring(startIndex);
        // From startIndex to end of string
        String tmp = s.substring(5);
        System.out.println(tmp);
    }

    public static void p5()
    {
        String s = "Heejee";
        // Returns the index of the first letter of the first occurence of the substring
        int i = s.indexOf("jeep");
        System.out.println(i);
    }

    public static void p6()
    {
        // Math m = new Math(); <- CANNOT DO THIS DO NOT FALL THE DE_TRIX
        // Math.random() generates a double in the range 0.0 <= x < 1.0
        // Random Double between 1 and not including 100
        // (high - low) * Math.random() + low
        // double num = (100 - 1) * Math.random() + 1;

        // Random Integer between low and including high
        // (int) ((high - low) + 1) * Math.random() + low;
        // eg. 1 to 100 (int) ((100 - 1) + 1) * Math.random() + 1;
        // eg. 5 to 26 (int) ((26 - 5) + 1) * Math.random() + 5;

        for (int i = 0; i < 300; i++) {
            int tmp = (int) (Math.random() * 22) + 5;
            System.out.println(tmp);
        }
    }

    public static void p7()
    {
        double x = 0.0;
        Double x2 = 0.0; // Wrapper class for double

        // Auto-boxing -> Automatically putting it in a box
        // Unboxing -> Automatically removing it from a box
        double j = x2 + x; // Unboxing

        Double y = x; // Auto-boxing
    }
}
