package Wrapper;

public class Tank extends Landcraft {
    
    private int serialNum;
    private String type;
    private int operatorCount;

    public Tank(int _serialNum, double _weight, String _type)
    {
        super(_weight);
        serialNum = _serialNum;
        type = _type;
    }

    public boolean equals(Tank other)
    {
        if (!super.equals(other)) return false; // Use the super class' equals first then compare

        // Check super class fields first, then check specific subclass fields
        return (this.getSerial() == other.getSerial() &&
                this.getType().equals(other.type));
    }

    public int getSerial() { return serialNum; }
    public String getType() { return type; }

    public String toString() {
        return "Tank #" + serialNum + ", weight: " + super.getWeight() + "lbs., type: " + type;
    }
}
