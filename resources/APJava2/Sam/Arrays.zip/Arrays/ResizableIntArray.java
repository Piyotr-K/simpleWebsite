public class ResizableIntArray {

    // Fields go here
    // Make use of a private integer that keeps track of
    // where the last item is in the array

    // To increase array size double the current size
    
    /**
     * Example resizable array
     * 
     * Uses a primitive int array as its base
     * Do not use an ArrayList or any List Object
     */
    public ResizableIntArray()
    {

    }

    /**
     * Adds the num to the array
     * @param num
     */
    public void Add(int num)
    {

    }

    /**
     * Remove the item at the given index (idx)
     * @param idx
     * @return
     */
    public int Remove(int idx)
    {
        return 0;
    }

    /**
     * Get the item at the given index (idx)
     * @param idx
     * @return
     */
    public int Get(int idx)
    {
        return 0;
    }

    /**
     * Set the item at the given index (idx)
     * @param idx
     * @param num
     * @return
     */
    public void Set(int idx, int num)
    {

    }

    /**
     * Returns the size of the array up to the last item
     * @return
     */
    public int Size()
    {
        return 0;
    }

    /**
     * Output in human readble format
     */
    public String toString()
    {
        return "";
    }

    /**
     * Resizes the array
     */
    private void resize()
    {

    }

    // Whatever other stuff lol
}