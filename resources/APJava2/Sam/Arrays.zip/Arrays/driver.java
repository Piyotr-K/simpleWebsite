import java.util.ArrayList;
import java.util.List;

public class driver {
    
    public static void main(String[] args) {
        ArrayList<Integer> arr1 = new ArrayList<Integer>();
        change(arr1);
        System.out.println(arr1);

        // arr1.add(5);
        // arr1.add(6);
        // arr1.add(7);
        // arr1.add(2);
        // arr1.add(1);

        // System.out.println(arr1);
        // System.out.println(arr1.size());
        // System.out.println(arr1.get(0));
        // arr1.add(1, 10);
        // System.out.println(arr1);
    }

    public static void change(ArrayList<Integer> arr)
    {
        arr = new ArrayList<Integer>();
        arr.add(6);
    }
}
