package Animals;

public class Bird extends Animal {

    private double flyingSpeed;

    // Zero-param constructor IS the same as the default constructor
    // public Bird() {}

    public Bird(int _age, String _name, double _flyingSpeed)
    {
        super(_age, _name);
        flyingSpeed = _flyingSpeed;
    }

    public double getFlyingSpeed() { return flyingSpeed; }
    public void setFlyingSpeed(double _flyingSpeed) { flyingSpeed = _flyingSpeed; }
}
