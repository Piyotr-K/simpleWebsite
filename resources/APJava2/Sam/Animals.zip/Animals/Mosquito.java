package Animals;

public class Mosquito implements FlyingObject {
    
    public void fly()
    {
        System.out.println("Moquito flying");
    }
}
