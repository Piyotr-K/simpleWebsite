package Animals;

public class Dolphin extends Animal {

    private double swimSpeed;
    
    public Dolphin(int _age, String _name, double _swimSpeed)
    {
        super(_age, _name);
        swimSpeed = _swimSpeed;
    }

    public double getSwimSpeed() { return swimSpeed; }
    public void setSwimSpeed(double _swimSpeed) { swimSpeed = _swimSpeed; }

    public void normalSpeak()
    {
        System.out.println("Echo echo");
    }

    public void magicSpeak()
    {
        normalSpeak();
    }
}
