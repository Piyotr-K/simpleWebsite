package Animals;

import java.util.ArrayList;

public class driver {

    public static void main(String[] args) {
        ArrayList<Animal> zoo = new ArrayList<Animal>();
        Dolphin e1 = new Dolphin(5, "Echo", 100.5);
        Dog d1 = new Dog(6, "Coggy", 25.3);
        ((Dolphin)e1).getSwimSpeed();
        zoo.add(e1);
        zoo.add(d1);

        System.out.println(d1.hashCode());

        // Early/Static-binding
        // Overloading - Changing parameters

        // Late/Dynamic-binding
        // Overriding - Changing actual stuff inside the function
    }

    public static void flyTime(ArrayList<FlyingObject> arr)
    {
        for (FlyingObject f : arr) f.fly();
    }

    public static void printAll(ArrayList<Dog> arr)
    {
        for (Animal d : arr) System.out.println(d.getName());
    }

    public static void p(Double d)
    {
        System.out.println(d);
    }

    public static void p(String s)
    {
        System.out.println(s);
    }

    public static void p(int i)
    {
        System.out.println(i);
    }
}
