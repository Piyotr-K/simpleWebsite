package Animals;

public class driver {

    public static void main(String[] args) {
        Dolphin e1 = new Dolphin(5, "Echo", 100.5);
        Dog d1 = new Dog(6, "Coggy", 25.3);
        p(e1.getSwimSpeed());
        p(d1.getRunSpeed());
    }

    public static void p(Double d)
    {
        System.out.println(d);
    }

    public static void p(String s)
    {
        System.out.println(s);
    }

    public static void p(int i)
    {
        System.out.println(i);
    }
}
