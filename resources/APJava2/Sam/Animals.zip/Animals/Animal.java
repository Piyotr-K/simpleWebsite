package Animals;

public class Animal {

    private int age;
    private String name;

    public Animal(int _age, String _name)
    {
        age = _age;
        name = _name;
    }

    public void speak()
    {
        System.out.println("Animal Speak");
    }

    public int getAge()
    {
        return age;
    }

    public void setAge(int _age)
    {
        age = _age;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String _name)
    {
        name = _name;
    }
    
}
