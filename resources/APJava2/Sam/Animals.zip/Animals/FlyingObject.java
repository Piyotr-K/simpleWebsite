package Animals;

public interface FlyingObject {
    public void fly();
}
