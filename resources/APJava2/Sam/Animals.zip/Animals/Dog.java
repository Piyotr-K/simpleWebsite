package Animals;

public class Dog extends Animal {

    private double runSpeed;

    public Dog(int _age, String _name, double _runSpeed)
    {
        super(_age, _name);
        runSpeed = _runSpeed;
    }

    public double getRunSpeed() { return runSpeed; }
    public void setRunSpeed(double _runSpeed) { runSpeed = _runSpeed; }
}
