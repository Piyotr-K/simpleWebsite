package Animals;

public class Dog extends Animal {

    private double runSpeed;

    public Dog(int _age, String _name, double _runSpeed)
    {
        super(_age, _name);
        runSpeed = _runSpeed;
    }

    // Overloading constructor
    // java only looks at the types, not the names
    public Dog(int _age, String _name)
    {
        super(_age, _name);
    }

    // Counts as overloading
    public Dog(double _age, String _name)
    {
        super((int)_age, _name);
    }

    public static void test()
    {
        System.out.println("Dog time.");
    }

    public double getRunSpeed() { return runSpeed; }
    public void setRunSpeed(double _runSpeed) { runSpeed = _runSpeed; }

    public void normalSpeak()
    {
        System.out.println("Ruff ruff");
    }

    public void magicSpeak()
    {
        normalSpeak();
    }

}
