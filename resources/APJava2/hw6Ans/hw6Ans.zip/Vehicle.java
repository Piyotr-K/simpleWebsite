package hw6;

public abstract class Vehicle {
    private int VIN;
    private int topSpeed;
    private double weight;
    private String make;
    private String model;

    public Vehicle(int VIN, int topSpeed, double weight, String make, String model) {
        this.VIN = VIN;
        this.topSpeed = topSpeed;
        this.weight = weight;
        this.make = make;
        this.model = model;
    }

    public abstract void drive();

    public int getVIN() {
        return VIN;
    }

    public int getTopSpeed() {
        return topSpeed;
    }

    public double getWeight() {
        return weight;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    @Override
    public String toString()
    {
        return "VIN: " + this.VIN + "\n" +
                "topSpeed: " + this.topSpeed + "\n" +
                "weight: " + this.weight + "\n" +
                "make: " + this.make + "\n" +
                "model: " + this.model;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) // If you're comparing this object to itself
            return true;
        
        if (o == null || this.getClass() != o.getClass())
            return false;

        Vehicle v1 = (Vehicle) o;

        if (this.VIN == v1.VIN)
            return true;
        return false;
    }
}
