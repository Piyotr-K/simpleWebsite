package src.ineritance;

public interface FlyingObject {
    public void fly();
}