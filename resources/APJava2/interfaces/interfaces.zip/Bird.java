package src.ineritance;

public class Bird extends Animal implements FlyingObject {
    private double maxFlightHeight;

    public Bird(String name, int age, double maxFlightHeight)
    {
        super(name, age);
        this.maxFlightHeight = maxFlightHeight;
    }

    public double getMaxFlightHeight()
    {
        return maxFlightHeight;
    }

    public void normalSpeak()
    {
        System.out.println("tweet tweet");
        System.out.println("Chirp Chirp");
        System.out.println("Caw Caw");
    }

    public void magicSpeak()
    {
        normalSpeak();
        super.magicSpeak();
    }

    @Override
    public void fly()
    {
        System.out.println("Bird Flyingggg");
    }
}
