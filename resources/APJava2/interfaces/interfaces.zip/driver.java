package src.ineritance;

public class driver {
    
    public static void main(String[] args)
    {
        Zoo zoo1 = new Zoo();
        Dog dog = new Dog("Snoopy", 10, 5);
        Animal bird = new Bird("Woodstock", 5, 100);
        Dolphin dolph = new Dolphin("Johnny", 7, 500);
        Insect mojito = new Mosquito("Angery", 1, 5, 12);

        zoo1.add(dolph);
        zoo1.add(bird);
        zoo1.add(dog);

        dog.normalSpeak();
        System.out.println(((Bird)bird).getMaxFlightHeight());
        dolph.magicSpeak();
        isFlying((Mosquito) mojito);
        isFlying((Bird) bird);

        zoo1.listAllAnimals();
    }

    public static void isFlying(FlyingObject fl)
    {
        fl.fly();
    }
}
