package src.ineritance;

public class Mosquito extends Insect implements FlyingObject {

    double poisonVolume;
    
    public Mosquito(String name, int age, double size, double poisonVolume)
    {
        super(name, age, size);
        this.poisonVolume = poisonVolume;
    }

    public void normalSpeak()
    {
        System.out.println("Bzzzzzzzzzzzz");
    }

    public double getPoisonVolume()
    {
        return poisonVolume;
    }

    public void fly()
    {
        System.out.println("Mosquito Flyingggg");
    }
}
