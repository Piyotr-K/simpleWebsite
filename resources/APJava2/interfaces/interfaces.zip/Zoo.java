package src.ineritance;

import java.util.ArrayList;

public class Zoo {
    
    ArrayList<Animal> animals = new ArrayList<Animal>();

    void add(Animal a)
    {
        animals.add(a);
    }

    boolean incrementAge(String name, int age)
    {
        for (Animal a : animals)
            if (a.getName().equals(name) && a.getAge() == age)
            {
                a.setAge(age + 1);
                return true;
            }
        return false;
    }

    void listAllAnimals()
    {
        for (Animal a : animals)
        {
            System.out.println(a.getName());
        }
    }
}
