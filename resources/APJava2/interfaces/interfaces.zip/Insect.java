package src.ineritance;

public abstract class Insect extends Animal {

    double size;
    
    public Insect(String name, int age, double size)
    {
        super(name, age);
        this.size = size;
    }

    public double getSize()
    {
        return size;
    }
}
