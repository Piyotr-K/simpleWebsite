package hw4;

/**
 * Created by Patrick on 2017-08-13.
 */
public class ElectricCar extends Car {

    private int maxRange;

    public ElectricCar(int VIN, int topSpeed, double weight, String make, String model, String type, int maxRange) {
        super(VIN, topSpeed, weight, make, model, type);
        this.maxRange = maxRange;
    }

    public int getMaxRange() {
        return maxRange;
    }
}
