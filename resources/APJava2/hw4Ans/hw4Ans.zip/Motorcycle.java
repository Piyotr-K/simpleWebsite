package hw4;

public class Motorcycle extends Vehicle {
    private int maxLeanAngle;

    public Motorcycle(int VIN, int topSpeed, double weight, String make, String model, int maxLeanAngle) {
        super(VIN, topSpeed, weight, make, model);
        this.maxLeanAngle = maxLeanAngle;
    }

    public int getMaxLeanAngle() {
        return maxLeanAngle;
    }
}
