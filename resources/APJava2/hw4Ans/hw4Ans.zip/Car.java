package hw4;

public class Car extends Vehicle {
    public String type;

    public Car(int VIN, int topSpeed, double weight, String make, String model, String type) {
        super(VIN, topSpeed, weight, make, model);
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
