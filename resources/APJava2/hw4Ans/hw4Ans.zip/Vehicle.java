package hw4;

public class Vehicle {
    private int VIN;
    private int topSpeed;
    private double weight;
    private String make;
    private String model;

    public Vehicle(int VIN, int topSpeed, double weight, String make, String model) {
        this.VIN = VIN;
        this.topSpeed = topSpeed;
        this.weight = weight;
        this.make = make;
        this.model = model;
    }

    public void drive()
    {
        System.out.println("Vehicle drive");
    }

    public int getVIN() {
        return VIN;
    }

    public int getTopSpeed() {
        return topSpeed;
    }

    public double getWeight() {
        return weight;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }
}
