package hw4;

public class driver {
    
    public static void main(String[] args)
    {
        Boat boat1 = new Boat(54473, 50, 600.0, "Boat", "Big Boat", 5);
        boat1.drive();
    }
}