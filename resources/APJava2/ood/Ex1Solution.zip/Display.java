package src.exercise;

import java.util.Scanner;

/**
 * Display.java
 * 
 * Handles all in and out put for the IDMain program
 * Should ONLY have input and output
 * 
 * @author Piyotr Kao
 * @version 1.0
 * @date-modified 2021-10-03
 */
public class Display {

    // Scanner for taking input
    private Scanner s1;

    // Id here to keep track of the id the user entered
    private IDNumber id;
    
    /**
     * Initializes a new instance of the Display class
     */
    public Display()
    {
        // Have to initialize a scanner before you use it
        s1 = new Scanner(System.in);
    }

    /**
     * writeToDisplay
     * 
     * Self-explanatory, really just a wrapper for the
     * sysout function, 
     * 
     * @param s string to output
     */
    public void writeToDisplay(String s)
    {
        System.out.println(s);
    }

    /**
     * takeInput
     * 
     * Take input from the user
     */
    public void takeInput()
    {
        this.writeToDisplay("Please enter your number");
        String userId = s1.nextLine();
        this.id = new IDNumber(userId);
        this.writeToDisplay("Thankz");
    }

    /**
     * printId
     * 
     * Custom print out format
     */
    public void printId()
    {
        for (int digit : this.id.getArr())
        {
            System.out.print(digit + " ");
        }
    }

    /**
     * displayValidity
     * 
     * Print out whether or not the id entered is valid
     */
    public void displayValidity()
    {
        this.writeToDisplay("Your code is: " + this.id.isValid());
    }
}
