package src.exercise;

/**
 * IDMain.java
 * 
 * id driver method for an implemented solution
 * to the example problem on p. 212 of
 * APCS 7th Edition Textbook
 * 
 * @author Piyotr Kao
 * @version 1.0
 * @date-modified 2021-10-03
 */
public class IDMain {
    
    public static void main(String[] args)
    {
        Display d1 = new Display();
        d1.writeToDisplay("Welcome to the printer lol");
        d1.takeInput();
        d1.displayValidity();
    }
}
