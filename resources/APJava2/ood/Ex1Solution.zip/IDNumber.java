package src.exercise;

/**
 * IDNumber.java
 * 
 * IDNumber class containing information pertaining to the
 * id entered.
 * 
 * @author Piyotr Kao
 * @version 1.0
 * @date-modified 2021-10-03
 */
public class IDNumber {
    
    // Id stored in an array format, can be any format
    // I just chose array
    private int[] idNum;

    /**
     * IDNumber
     * 
     * Constructor that creates an object based on
     * an array passed through as a parameter
     * 
     * This is only a shallow copy, can be changed to a deep
     * copy but not necessary for the sake of example
     * 
     * @param num the reference to the id array used
     */
    public IDNumber(int[] num)
    {
        // Shallow copy of the array
        this.idNum = num;
    }

    /**
     * IDNumber
     * 
     * Constructor that creates an object based on
     * a String passed through as a parameter
     * 
     * @param num the string to store
     */
    public IDNumber(String num)
    {
        // Can add checks for ensuring the id entered is of length 4
        idNum = new int[4];

        // Deep copy the string over number by number
        for (int i = 0; i < num.length(); i++)
        {
            /* 
            String.charAt() here returns a char type
            all characters in programming have an ascii code
            if you were to straight up assign a char to an int
            it would assign the char's ascii value to the int
            so the code:

            char c = '5';
            int num = c; // c = 53 here

            So here I concatenated an empty String ("") to the front
            to convert the char into a String and then used the
            Integer.parseInt() function to transform the
            String "5" into the int 5
            */
            idNum[i] = Integer.parseInt("" + num.charAt(i));
        }
    }

    /**
     * getArr
     * 
     * @return int array
     */
    public int[] getArr()
    {
        return idNum;
    }

    /**
     * setArr
     * 
     * shallow copy here again
     * 
     * @param num int array
     */
    public void setArr(int[] num)
    {
        this.idNum = num;
    }

    /**
     * isValid
     * 
     * Based on a formula returns whether or not the number is valid
     * 
     * @return validity
     */
    public boolean isValid()
    {
        int sum = this.idNum[0] + this.idNum[1] + this.idNum[2];

        int remainder = sum % 7;

        if (this.idNum[3] == remainder)
            return true;
        return false;
    }
}
