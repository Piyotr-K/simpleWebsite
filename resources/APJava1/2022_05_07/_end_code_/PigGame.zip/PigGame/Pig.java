package PigGame;

public class Pig {
    
    public static void main(String[] args) {
        // Scanner, Random, Custom Classes
        // Player 1 vs Player 2
        // Player class
        // -> Score
        // -> 2 methods
        //  -> 1 called roll
        //  -> 1 called hold
        // Game ends when one of the players gets 100

        // Mainloop
        while (true)
        {
            // do stuff
            // If you need to quit
            // use break
        }

        // Steps:
        // 1.
        // Get the inputs working
        // -> Give the player their 2 choices, roll or hold
        // -> Process input
        // 2.
        // Scoring process
        // -> Using player class to keep track of scores and stuff
        // 3.
        // Win condition
        // -> How to end the game
    }
}