package Class14;

public class Animal {
    private String name;
    private int age;

    public Animal() {}
    
    public Animal(String _name) { name = _name; }

    public Animal(String _name, int _age)
    {
        age = _age;
        name = _name;
    }

    public void setName(String _name)
    {
        name = _name;
    }

    public String getName()
    {
        return name;
    }

    public void setAge(int _age)
    {
        age = _age;
    }

    public int getAge()
    {
        return age;
    }

    public void magicSpeak()
    {
        System.out.println("My name is " + name + " and I am " + age + " years old.");
    }
}
