package Class14;

public class Bird extends Animal {

    public Bird(String _name, int _age)
    {
        super(_name, _age);
    }

    public void magicSpeak()
    {
        System.out.println("I am a Bird");
        super.magicSpeak();
    }
}
