package Class14;

public class Mosquito extends Animal {
    // By default
    // Object properties (ex. String, Scanner) are initialized to null
    // ints properties and doubles properties are set to 0 and 0.0
    // booleans properties are set to false properties

    public Mosquito() {}

    public void magicSpeak()
    {
        System.out.println("I am a Mosquito");
        super.magicSpeak();
    }
}
