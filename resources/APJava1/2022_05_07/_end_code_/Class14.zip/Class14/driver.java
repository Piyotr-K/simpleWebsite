package Class14;

public class driver {

    // Static binding/Early binding
    // part1() -> Before code is run (compile-time) java knows where the function is
    // overloading() -> Also static binding

    // Dynamic binding/Late Binding
    // magicSpeak() -> Happens during (run-time) java finds which function you're calling and uses that one
    
    // Different stages of Java Code
    // 1. Compiles the code to bytecode -> converts human readable code to computer readable code
    // (Compile time)
    // 2. Executes the bytecode that was compiled
    // (Run time)

    public static void main(String[] args) {
        part1();
    }

    public static void part1()
    {
        int x = (int) 1.5;
        Animal d = new Dog("wew", 5);
        // Animal d = new Dog();
        Animal m = new Mosquito();
        m.magicSpeak();
        ((Dog) d).getBiteStren();
    }
}
