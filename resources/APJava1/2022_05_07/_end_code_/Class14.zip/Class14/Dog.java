package Class14;

public class Dog extends Animal {
    private String biteStrength;

    public Dog() { super(); }

    public Dog(String _name, int _age)
    {
        super(_name, _age);
    }

    public Dog(String _name, int _age, String _bite)
    {
        super(_name, _age);
        biteStrength = _bite;
    }

    public void setBite(String _bite)
    {
        biteStrength = _bite;
    }

    public String getBiteStren() { return biteStrength; }

    // Example of OVERRIDING
    public void magicSpeak()
    {
        System.out.println("I am a Dog");
        super.magicSpeak();
    }
}
