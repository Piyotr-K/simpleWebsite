package Class13;

public class driver {
    
    public static void main(String[] args) {
        part4();
    }

    public static void part1()
    {
        int x = 5, y = 2;

        System.out.println("Before the function, x is " + x + " y is " + y);
        random(x, y);
        System.out.println("After the function, x is " + x + " y is " + y);
    }

    public static void part2()
    {
        // Test t = new Test();
        // System.out.println("Main thread t: " + t);
        // System.out.println("Main thread t value: " + t.getThing());
        // random2(t);
        // System.out.println("Main thread t: " + t);
        // System.out.println("Main thread t value: " + t.getThing());

        int[] arr = new int[5];
        printArr(arr);
        random3(arr);
        printArr(arr);
    }

    public static void part3()
    {
        Test t = new Test();
        Test jej = t;
        Test yey = jej;
        foobar(yey);
        System.out.println(t);
        System.out.println(jej);
        System.out.println(yey);
    }

    public static void part4()
    {
        Dog d = new Dog("Barkman", 5);
        System.out.println(d.getAge());
    }

    public static void random(int x, int y)
    {
        // Could use a wrapper class
        // Integer
        x = 10;
        y = 20;
    }

    public static void random2(Test t)
    {
        System.out.println("Function t: " + t);
        t.setThing(10);
    }

    public static void random3(int[] a)
    {
        for (int i = 0; i < a.length; i++)
            a[i] = 10;
    }

    public static void foobar(Test t)
    {
        Test t3 = t;
        Test e = t;
        System.out.println(t);
        System.out.println(t3);
        System.out.println(e);
    }

    public static void printArr(int[] a)
    {
        for (int i = 0; i < a.length; i++)
            System.out.println(a[i]);
    }
}
