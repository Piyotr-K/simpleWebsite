package Class13;

public class Bird {
    
    private String name;
    private int age;

    public Bird(String _name, int _age)
    {
        name = _name;
        age = _age;
    }

    public void speak()
    {
        System.out.println("Bird says chirp");
    }
}
