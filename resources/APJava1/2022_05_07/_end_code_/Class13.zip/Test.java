package Class13;

public class Test {
    
    // field or property or instance variable or attribute
    private int thing;

    public Test()
    {
        thing = 0;
    }

    public int getThing()
    {
        return thing;
    }

    public void setThing(int _thing)
    {
        thing = _thing;
    }
}
