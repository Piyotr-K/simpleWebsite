package Class13;

public class Animal {
    private String name;
    private int age;

    public Animal()
    {
        
    }

    public Animal(int _age, String _name)
    {
        age = _age;
        name = _name;
    }

    public void setName(String _name)
    {
        name = _name;
    }

    public String getName()
    {
        return name;
    }

    public void setAge(int _age)
    {
        age = _age;
    }

    public int getAge()
    {
        return age;
    }

    public void speak()
    {
        System.out.println("Dog says bark");
    }
}
