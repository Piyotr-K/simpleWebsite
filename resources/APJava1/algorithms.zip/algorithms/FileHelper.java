package algorithms;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class FileHelper {

    private String fileName;
    private File file;
    private ArrayList<String> data;

    public FileHelper(String filename)
    {
        this.fileName = filename;
        this.file = new File(this.fileName);
        data = new ArrayList<String>();
        readFile();
    }

    private void readFile()
    {
        try
        {
            Scanner s = new Scanner(this.file);
            while (s.hasNextLine())
            {
                String line = s.nextLine();
                data.add(line);
            }
        }
        catch (FileNotFoundException e)
        {
            System.out.println("File not found!");
        }
    }

    public ArrayList<String> getDataList()
    {
        return data;
    }
    
    public int[] getData()
    {
        int[] out = new int[data.size()];
        for (int i = 0; i < data.size(); ++i)
        {
            out[i] = Integer.parseInt(data.get(i));
        }
        return out;
    }
}
