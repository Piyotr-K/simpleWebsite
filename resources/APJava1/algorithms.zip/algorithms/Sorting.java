package algorithms;

public class Sorting {

    public static void main(String[] args) {
        int[] arr = {5, 2, 4, 1, 3, 6}; // {1, 2, 3, 4, 5, 6}
        selectionSort(arr);
        printArr(arr);
    }

    public static void selectionSort(int[] a)
    {
        // two numbers that remember the current min and the new min
        //
        // Loop 1:
        // x and y
        // x compares y at 3 and 5
        // min
        // Loop 2:
        // x and y
        // min
    }

    public static void printArr(int[] a)
    {
        for (int n : a)
            System.out.print(n + " ");
    }
}