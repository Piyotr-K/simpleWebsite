package algorithms;
import java.util.Arrays;

public class Sorting {

    public static void main(String[] args) {
        int[] arr = {5, 2, 4, 1, 3, 6, 7}; // {1, 2, 3, 4, 5, 6}
        mergeSort(arr);
        printArr(arr);
    }

    public static void selectionSort(int[] a)
    {
        for (int i = 0; i < a.length; i++)
            for (int j = i + 1; j < a.length; j++)
                if (a[j] < a[i])
                    swap(a, j, i);
    }

    public static void insertionSort(int[] a)
    {
        int j = 0;
        for (int i = 1; i < a.length; i++)
        {
            j = i;
            while (j > 0 && a[j] < a[j - 1])
            {
                swap(a, j, j - 1);
                j = j - 1;
            }
        }
    }

    public static void swap(int[] arr, int a, int b)
    {
        int temp = arr[a];
        arr[a] = arr[b];
        arr[b] = temp;
    }

    public static int[] mergeSort(int[] a)
    {
        if (a.length == 1)
            return a;
        else
        {
            int mid = a.length / 2;
            int[] left = Arrays.copyOfRange(a, 0, mid);
            int[] right = Arrays.copyOfRange(a, mid, a.length);
            left = mergeSort(left);
            right = mergeSort(right);

            return merge(left, right);
        }
    }

    private static int[] merge(int[] a, int[] b)
    {
        int[] c = new int[a.length + b.length];
        int i = 0, j = 0, k = 0;
        while(i < a.length && j < b.length)
        {
            // If left side first num is smaller
            // Add it to the front of c
            if (a[i] < b[j])
            {
                c[k] = a[i];
                i++;
            }
            // If right side first num is smaller
            // Add it to the front of c
            else
            {
                c[k] = b[j];
                j++;
            }
            k++;
        }

        // Adding up the remaining numbers
        // if there are any
        while (i < a.length)
        {
            c[k] = a[i];
            i++;
            k++;
        }
        
        // Adding up the remaining numbers
        // if there are any
        while (j < b.length)
        {
            c[k] = b[j];
            j++;
            k++;
        }

        return c;
    }

    public static void printArr(int[] a)
    {
        for (int n : a)
            System.out.print(n + " ");
    }
}