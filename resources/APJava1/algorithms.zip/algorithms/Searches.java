package algorithms;

public class Searches {

    public static int binaryCounter = 0;
    public static int noobCounter = 0;
    
    public static void main(String[] args) {
        FileHelper f = new FileHelper("./algorithms/Lines_1_10000.csv");
        // int[] haystack = {5, 2, 4, 1, 3, 6};
        // int[] haystack2 = {1, 3, 5, 6, 7, 9, 11, 15, 18, 20};
        int result, result2;
        // result = sequentialSearch(haystack, 6);
        int[] manyNumbers = f.getData();

        long start1 = System.nanoTime();
        result = binarySearchRecursive(manyNumbers, 5349, 0, manyNumbers.length - 1);
        long end1 = System.nanoTime();
        long duration1 = (end1 - start1);

        long start2 = System.nanoTime();
        result2 = sequentialSearch(manyNumbers, 5349);
        long end2 = System.nanoTime();
        long duration2 = (end2 - start2);

        System.out.println("binary Result: " + result);
        System.out.println("Binary Comparisons: " + binaryCounter);
        System.out.println("Binary Time taken: " + duration1);

        System.out.println("sequential Result: " + result2);
        System.out.println("Sequential Comparisons: " + noobCounter);
        System.out.println("Sequential Time taken: " + duration2);
    }

    // Return the index (position) of the item found
    // If the item cannot be found, return -1 for not found.
    public static int sequentialSearch(int[] a, int n)
    {
        for (int i = 0; i < a.length; i++)
        {
            noobCounter += 1;
            if (n == a[i])
                return i;
        }
        return -1;
    }

    // Return the index (pos) of the item found
    // Otherwise return -1
    // precondition: a (array) must be sorted
    public static int binarySearchIterative(int[] a, int n)
    {
        int low = 0;
        int high = a.length - 1;
        while (low <= high)
        {
            binaryCounter += 1;
            int mid = (high + low) / 2;
            if (n < a[mid])
                high = mid - 1; // {1, 3, 4, 5, 6, 7, 9, 11} -> 3
                                // {1, 3, 4}
            else if (n > a[mid])
                low = mid + 1;  // {1, 3, 4, 5, 6, 7, 9, 11} -> 9
                                // {6, 7, 9, 11}
            else return mid;    // {1, 3, 4, 5, 6, 7, 9, 11} -> 5
                                // gottem boyz
        }
        return -1;
    }

    public static int binarySearchRecursive(int[] a, int n, int low, int high)
    {
        binaryCounter += 1;
        if (low > high)
            return -1;
        
        int mid = (low + high) / 2;
        if (n == a[mid])
            return mid;
        else if (n > a[mid])
            return binarySearchRecursive(a, n, mid + 1, high);
        else
            return binarySearchRecursive(a, n, low, mid - 1);
    }
}
