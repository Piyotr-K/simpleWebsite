package src.com;

public class Book extends Media {

    private int chapters;

    public Book(String title, String author, String date, int chapters)
    {
        super(title, author, date);
        this.chapters = chapters;
    }

    public int getChapters()
    {
        return this.chapters;
    }

    public void setChapters(int chapters)
    {
        this.chapters = chapters;
    }

    public String toString()
    {
        String out = "";
        out += super.toString();
        out += this.chapters + " chapters long.";
        return out;
    }
}
