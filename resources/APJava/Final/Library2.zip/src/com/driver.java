package src.com;

public class driver {

    public static void main(String[] args)
    {
        Display d = new Display("Vancouver Public Library");
        d.start();
    }

    public static void testLibrary()
    {
        // Library lib = new Library("VPL");
        // lib.add(new Book("Moby Dick", "Herman Melville", "1412", 20));
        // lib.add(new Book("Garfield", "Jim Davis", "1992", 15));
        // lib.add(new Video("Garfield Movie.mp4", "Steven Spielberg", "1992", 20, 49392, 30));
        // lib.add(new Book("( ͡❛ ⏥ ͡❛)", "Jonathan Gong", "2021", 25));
        // lib.add(new AudioClip("Unfinished Song.mp3", "deadmau5", "2004", 24, 300));
        // lib.add(new Video("FunnyVideoPleaseLaugh.mp4", "Vincent Persechetti", "1950", 24, 360, 30));

        // System.out.println(lib.listAll());
        // System.out.println(lib.search("Moby Dick"));
        // System.out.println(lib.search("1992"));
    }
}
