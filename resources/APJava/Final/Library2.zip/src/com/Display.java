package src.com;

import java.util.Scanner;

public class Display {
    // Show a menu and take input and what not

    private Library l;
    private Scanner s;
    private boolean finished = false;

    public Display(String libraryName)
    {
        l = new Library(libraryName);
        s = new Scanner(System.in);
    }

    public void start()
    {
        while (!finished)
        {
            this.dMainMenu();
            processInput(s.nextLine());
        }
    }

    public void processInput(String in)
    {
        switch (in)
        {
            case "1":
                // Add
                dAdd();
                break;
            case "2":
                // Remove
                dRemove();
                break;
            case "3":
                // List all
                displayAll();
                break;
            case "4":
                // Search
                break;
            case "5":
                // Exit
                this.finished = true;
                System.out.println("Thank you for using beeg library.");
                break;
            default:
                // If they didn't enter a correct option
                System.out.println("Invalid Option, try again");
                break;
        }
    }

    public void dMainMenu()
    {
        String menu = "";
        menu += "1. Add Media\n";
        menu += "2. Remove Media\n";
        menu += "3. List All Media\n";
        menu += "4. Search Media by query\n";
        menu += "5. Exit";
        System.out.println(menu);
    }

    public void dAdd()
    {
        String out = "";
        String userIn;
        out += "Please choose what you want to add to the library.\n";
        out += "(B)ook, (V)ideo, (A)udioClip\n";
        out += "(C)ancel";
        System.out.println(out);

        boolean done = false;

        while (!done)
        {
            userIn = this.s.nextLine();
            switch (userIn)
            {
                case "B":
                    addMedia("book");
                    done = true;
                    break;
                case "V":
                    addMedia("video");
                    done = true;
                    break;
                case "C":
                    System.out.println("Exiting");
                    done = true;
                    break;
                default:
                    System.out.println("Invalid Input");
                    break;
            }
        }
    }

    public void dRemove()
    {
        System.out.println("Please enter the title of the media item to remove:");
        // What if they type an invalid name??
        Media m = this.l.search(this.s.nextLine()).get(0);
        this.l.remove(m);
        System.out.println(m.getTitle() + " has been removed.");
    }

    public void addMedia(String type)
    {
        String title, author, date;
        int chapters, decibels, duration, fps;
        switch (type)
        {
            case "book":
                System.out.println("Enter the title: ");
                title = this.s.nextLine();
                System.out.println("Enter the author: ");
                author = this.s.nextLine();
                System.out.println("Enter the date: ");
                date = this.s.nextLine();
                System.out.println("Enter the chapter count: ");
                chapters = Integer.parseInt(s.nextLine());
                this.l.add(new Book(title, author, date, chapters));
                break;
            case "video":
                System.out.println("Enter the title: ");
                title = this.s.nextLine();
                System.out.println("Enter the author: ");
                author = this.s.nextLine();
                System.out.println("Enter the date: ");
                date = this.s.nextLine();
                System.out.println("Enter the average decibels: ");
                decibels = Integer.parseInt(s.nextLine());
                System.out.println("Enter the duration of the video: ");
                duration = Integer.parseInt(s.nextLine());
                System.out.println("Enter the fps of the video: ");
                fps = Integer.parseInt(s.nextLine());
                this.l.add(new Video(title, author, date, decibels, duration, fps));
                break;
        }
    }

    public void displayAll()
    {
        System.out.println("All the items in da beeg library:");
        System.out.println(l.listAll());
    }
}
