package src.com;

public class Video extends DigitalMedia {

    private int framesPerSecond;

    public Video(String title, String author, String date,
                    int avgDecibels, int duration, int framesPerSecond)
    {
        super(title, author, date, duration, avgDecibels);
        this.framesPerSecond = framesPerSecond;
    }

    public int getFrames()
    {
        return this.framesPerSecond;
    }

    public void setFrames(int frames)
    {
        this.framesPerSecond = frames;
    }

    public String toString()
    {
        String out = "";
        out += super.toString();
        out += "at " + this.framesPerSecond + " frames per second ";
        return out;
    }
}
