package src.com;

public class AudioClip extends DigitalMedia {

    public AudioClip(String title, String author, String date,
                        int avgDecibels, int duration)
    {
        super(title, author, date, duration, avgDecibels);
    }

    public String toString()
    {
        String out = "";
        out += super.toString();
        return out;
    }

}
