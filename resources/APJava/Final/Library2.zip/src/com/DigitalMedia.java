package src.com;

public abstract class DigitalMedia extends Media {

    private int duration;
    private int avgDecibels;
    
    public DigitalMedia(String title, String author, String date, int duration, int avgDecibels)
    {
        super(title, author, date);
        this.duration = duration;
        this.avgDecibels = avgDecibels;
    }

    public int getDuration()
    {
        return this.duration;
    }

    public void setDuration(int duration)
    {
        this.duration = duration;
    }

    public int getDecibels()
    {
        return this.avgDecibels;
    }

    public void setDecibels(int decibels)
    {
        this.avgDecibels = decibels;
    }

    public String toString()
    {
        String out = "";
        out += super.toString();
        out += this.getDuration() + " seconds long,";
        out += " with an average decibel level of: " + this.getDecibels() + " ";
        return out;
    }
}
