package src.com;

import java.util.ArrayList;

public class Library {

    private String name;
    private ArrayList<Media> allItems;

    public Library(String name)
    {
        this.name = name;
        allItems = new ArrayList<Media>();
    }

    public void add(Media item)
    {
        allItems.add(item);
    }

    public ArrayList<Media> search(String query)
    {
        ArrayList<Media> out = new ArrayList<Media>();
        for (Media m : allItems)
            if (m.getTitle().equals(query)
                || m.getAuthor().equals(query)
                || m.getDate().equals(query))
                out.add(m);
        return out;
    }

    public void remove(Media item)
    {
        allItems.remove(item);
    }

    public String listAll()
    {
        String out = "";
        for (Media m : allItems)
        {
            out += m.toString() + "\n";
        }
        return out;
    }

}
