package src.example;

public class Dog extends Animal {
    private double runSpeed;

    public Dog(String name, int age, int runSpeed)
    {
        super(name, age);
        this.runSpeed = runSpeed;
        // System.out.println("Dog Constructor Called");
    }

    public Dog() { super("", 0); }

    public double getRunSpeed()
    {
        return runSpeed;
    }

    @Override
    public void normalSpeak()
    {
        System.out.println("Ruff Ruff");
    }

    public void magicSpeak()
    {
        normalSpeak();
        super.magicSpeak();
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) // If you're comparing this object to itself
            return true;
        
        if (o == null || this.getClass() != o.getClass())
            return false;
        
        if (!super.equals(o)) return false;
        
        Dog d1 = (Dog) o;

        if (this.runSpeed == d1.runSpeed)
            return true;
        return false;
    }
}
