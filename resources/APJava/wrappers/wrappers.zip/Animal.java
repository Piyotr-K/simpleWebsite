package src.example;

public abstract class Animal {

    private String name;
    private int age;

    // Animal constructor
    public Animal(String name, int age)
    {
        this.name = name;
        this.age = age;
        // System.out.println("Animal Constructor Called");
    }

    // public Animal() {}

    public String getName()
    {
        return name;
    }

    public int getAge()
    {
        return age;
    }

    public void setAge(int age)
    {
        this.age = age;
    }   

    public abstract void normalSpeak();

    public void magicSpeak()
    {
        System.out.println("Hello my name is " + name + ". I am " + age + " years old.");
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) // If you're comparing this object to itself
            return true;
        
        if (o == null || this.getClass() != o.getClass())
            return false;
        
        Animal a = (Animal) o;

        if (this.age == a.age && this.name == a.name)
            return true;
        return false;
    }

    @Override
    public String toString()
    {
        return "Animal: {" +
                "Name: '" + name + "\'" +
                ", Age: " + age + 
                "}";
    }
}