package src.example;

public class driver {
    
    public static void main(String[] args)
    {
        Animal dog = new Dog("Snoopyyyy", 10, 5);
        Animal dog1 = new Dog("Snoopyyyy", 10, 4);
        Animal dol1 = new Dolphin("Echo", 15, 38);

        Integer num1 = 5; // int
        Short short1 = 5; // short
        Long l1 = 5L; // long
        Byte b1 = 0x00; // byte
        Float fl1 = 5.0f; // float
        Double d1 = 5.0; // double
        Boolean boo1 = true; // boolean
        Character c1 = 'h'; // char

        String s1 = new String("cattle");
        String s2 = "cattlf";

        // System.out.println(dog);
        // System.out.println(dol1);
        // System.out.println(dog.equals(dog1));
        System.out.println(s1.compareTo(s2));
    }
}
