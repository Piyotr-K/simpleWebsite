package hw5;

public class GasCar extends Car implements ChargingObject {
    private int tankCapacity;

    public GasCar(int VIN, int topSpeed, double weight, String make, String model, String type, int tankCapacity) {
        super(VIN, topSpeed, weight, make, model, type);
        this.tankCapacity = tankCapacity;
    }

    public int getTankCapacity() {
        return tankCapacity;
    }

    public void drive()
    {
        System.out.println("GasCar drives");
    }

    public void charge()
    {
        System.out.println("GasCar charges forward");
    }
}
