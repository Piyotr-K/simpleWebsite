package hw5;

public class Boat extends Vehicle {
    private int carryingCapacity;

    public Boat(int VIN, int topSpeed, double weight, String make, String model, int carryingCapacity)
    {
        super(VIN, topSpeed, weight, make, model);
        this.carryingCapacity = carryingCapacity;
    }

    public int getCarryingCapacity() {
        return carryingCapacity;
    }

    public void drive()
    {
        System.out.println("Boat drive");
    }
}
