package hw5;

public interface ChargingObject {
    
    public void charge();
}
