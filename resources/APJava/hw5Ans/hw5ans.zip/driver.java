package hw5;

public class driver {
    
    public static void main(String[] args)
    {
        Boat boat1 = new Boat(54473, 50, 600.0, "Boat", "Big Boat", 5);
        boat1.drive();

        GasCar gc1 = new GasCar(54473, 50, 600.0, "Boat", "Big Boat", "Huge", 5);
        Goat g1 = new Goat();

        activateCharge(gc1);
        activateCharge(g1);
    }

    public static void activateCharge(ChargingObject c)
    {
        c.charge();
    }
}