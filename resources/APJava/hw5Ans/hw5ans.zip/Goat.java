package hw5;

public class Goat implements ChargingObject {
    
    public void charge()
    {
        System.out.println("Goat charges");
    }
}
