package src.ResizableArray;

public class DynamicIntArray {
    private int[] arr = new int[2];
    private int lastIndex = 0;

    public void push(int x){
        arr[lastIndex] = x;
        lastIndex++;

        if (isFull()){
            resize();
        }
    }

    public int pop() {
        int num = arr[lastIndex];
        lastIndex--;
        return num;
    }

    public int length() {
        return lastIndex + 1;
    }

    public boolean isFull() {
        if (arr.length - 1 == lastIndex)
            return true;
        return false;
    }

    private void resize(){
        int[] arrCopy = new int[arr.length * 2];
        for (int i = 0; i < arr.length; i++) {
            arrCopy[i] = arr[i];
        }
        arr = arrCopy;
    }

    public int at(int idx) {
        return arr[idx];
    }

    public void remove(int idx)
    {
        int[] tmp = new int[arr.length];
        int counter = 0;
        for (int i = 0; i < idx; i++)
        {
            tmp[counter] = arr[i];
            counter++;
        }
        for (int i = idx + 1; i < lastIndex; i++)
        {
            tmp[counter] = arr[i];
            counter++;
        }
        arr = tmp;
        lastIndex--;
    }

    public int[] getArr(){
        return arr;
    }

    public String toString()
    {
        String out = "";
        for (int i = 0; i < lastIndex; i++)
        {
            out += arr[i] + ", ";
        }
        return out;
    }
}
