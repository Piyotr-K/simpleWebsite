package src.ResizableArray;

public class driver {
    
    public static void main(String[] args)
    {
        DynamicIntArray arr1 = new DynamicIntArray();
        System.out.println(arr1);

        arr1.push(6);
        arr1.push(7);
        arr1.push(8);

        System.out.println(arr1);

        arr1.push(9);
        arr1.push(10);
        arr1.push(11);

        System.out.println(arr1);

        arr1.remove(1);
        arr1.remove(3);

        System.out.println(arr1);
    }
}
