import tkinter as T
import tkinter.messagebox

def random(event):
    print("hi!")
    print(event)

def greeting():
    print("Hello!")

def login(event):
    user = entry.get()
    passwd = entry2.get()

    if user == "huge" and passwd == "large":
        print("Login success!")
    
        loginFrame.place_forget()
        lbl = T.Label(root, text="Fun Game time!!!", font=("Consolas", 20))
        lbl.place(relx=.5, rely=.5, anchor=T.CENTER)
    else:
        tkinter.messagebox.showerror("Uh Oh Spaghetti O", "Incorrect Credentials!")

root = T.Tk()
root.geometry("500x500")

# Menu icons at the top right
fileMenu = T.Menu(root)
root.configure(menu=fileMenu)
fileMenu.add_command(label="Greeting1", command=greeting)

# Add buttons to this subMenu
subMenu = T.Menu(fileMenu, tearoff=False)
fileMenu.add_cascade(label="File",menu=subMenu)

# HW section
subMenu.add_command(label="Greeting2", command=greeting)

loginFrame = T.Frame(root)

lbl1 = T.Label(loginFrame, text="Name:")
lbl2 = T.Label(loginFrame, text="Password:")
lbl3 = T.Label(loginFrame, text="Welcome to fun game", font=("Consolas", 20))

entry = T.Entry(loginFrame)
entry2 = T.Entry(loginFrame, show="*")

lbl3.grid(row=0,column=0,columnspan=2)
lbl1.grid(row=1,column=0,sticky=T.E)
lbl2.grid(row=2,column=0,sticky=T.E)
entry.grid(row=1,column=1,sticky=T.W)
entry2.grid(row=2,column=1,sticky=T.W)

# Usually btn-1 is left click
# btn-2 is scrollwheel
# btn-3 is right click
# root.bind("<Button-1>", random)
# root.bind("p", random)
root.bind("<Return>", login)

loginFrame.place(relx=.5, rely=.5, anchor=T.CENTER)

# messagebox
# tkinter.messagebox.showinfo("Nice", "Message here")

# mainloop is important!
root.mainloop()

# Hw
# Required:
# Add a menu button for loading the employees
# Display all the employees IF the user is logged in
# Put it in the subMenu under fileMenu
# Make sure to make use of the employee class as well