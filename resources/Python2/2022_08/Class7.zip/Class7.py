import tkinter as Tk
import time as T
import random as R

colours = ["red", "blue", "yellow", "green", "purple", "cyan"]
allRect = []
def rect(x, y, w, h, c):
    return canvas.create_rectangle(x, y, x + w, y + h, fill=c)

def clear_list(l):
    for id in l:
        canvas.delete(id)

def gen_rect():
    if allRect != []:
        clear_list(allRect)

    for i in range(10):
        id = rect(
            R.randint(-30, 290),
            R.randint(-30, 290),
            R.randint(30, 100),
            R.randint(30, 100),
            R.choice(colours))
        allRect.append(id)

    root.update()

root = Tk.Tk()

canvas = Tk.Canvas(root, width=300, height=300)
canvas.configure(bg="darkgrey")
canvas.pack()

btn1 = Tk.Button(root, text="Generate Rectangles", command=gen_rect)
btn1.pack()
btn2 = Tk.Button(root, text="Play Animation")
btn2.pack()

textId = canvas.create_text(-20,140,text="Wow nice",font=('terminal', 30))

for i in range(200):
    canvas.move(textId, 2, 0)
    root.update()
    T.sleep(0.01)

root.mainloop()