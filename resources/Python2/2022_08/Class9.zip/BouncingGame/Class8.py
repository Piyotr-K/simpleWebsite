import tkinter as tk
import BallGame as bg
import time as T

def move_up(e):
    print(e)
    canvas.move(text, 0, -2)

root = tk.Tk()
root.resizable(0,0) # cannot resize window
root.wm_attributes("-topmost", 1) # makes the window stay on top all the time
root.title("Ball Gaem")

canvas = tk.Canvas(root, width=500, height=500)
canvas.pack()

text = canvas.create_text(250, 250, text="Fun Ball\nYeee", font=("consolas", 20))

root.update()
paddle = bg.Paddle(canvas, "red")
ball = bg.Ball(canvas, paddle, "red")

canvas.bind_all("r", ball.reset)

# Hw
# Required:
# If the ball touches the bottom
# Just display gameover in terminal
# (bonus ducks if you can get it to stop the game)
# Anytime the ball touches the paddle add to score
# Display score in terminal
# (bonus ducks if you can get it to display on screen)

while True:
    ball.draw()
    paddle.draw()
    root.update_idletasks()
    root.update()
    T.sleep(0.01)