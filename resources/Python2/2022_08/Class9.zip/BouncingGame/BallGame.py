import tkinter as tk
import random as R

class Ball():

    ball_count = 0

    def __init__(self, canvas, paddle, colour):
        self.canvas : tk.Canvas = canvas
        self.id = self.canvas.create_oval(10,10,25,25,fill=colour)
        self.canvas.move(self.id, 245, 100)

        self.paddle = paddle

        self.x_vel = R.randint(-2, 2)
        self.y_vel = R.randint(-2, 2)

        self.canvas_height = self.canvas.winfo_height()
        self.canvas_width = self.canvas.winfo_width()
    
    def draw(self):
        self.canvas.move(self.id, self.x_vel, self.y_vel)

        pos = self.canvas.coords(self.id)

        if self.hit_paddle(pos):
            self.y_vel *= -1

        # pos = [x1, y1, x2, y2]
        if pos[1] <= 0:
            self.y_vel *= -1
        if pos[3] >= self.canvas_height:
            self.y_vel *= -1
        if pos[0] <= 0:
            self.x_vel *= -1
        if pos[2] >= self.canvas_width:
            self.x_vel *= -1
    
    def hit_paddle(self, pos):
        paddle_pos = self.canvas.coords(self.paddle.id)
        if pos[2] >= paddle_pos[0] and pos[0] <= paddle_pos[2]:
            if pos[3] >= paddle_pos[1] and pos[3] <= paddle_pos[3]:
                return True
        return False
    
    def reset(self, e):
        self.canvas.moveto(self.id, 245, 100)
        self.y_vel = R.randint(-2, 2)
        self.x_vel = R.randint(-2, 2)

class Paddle():

    def __init__(self, canvas : tk.Canvas, color):
        self.canvas = canvas
        self.id = canvas.create_rectangle(0,0,100,10,fill=color)
        self.canvas.move(self.id, 200, 400)
        self.x = 0
        self.canvas_width = self.canvas.winfo_width()

        # <KeyPress-Left>
        # self.canvas.bind_all("a", self.move_left)
        # self.canvas.bind_all("d", self.move_right)
        self.canvas.bind("<B1-Motion>", self.move_paddle)
    
    def move_left(self, e):
        self.x = -2
    
    def move_right(self, e):
        self.x = 2
    
    def move_paddle(self, e : tk.Event):
        self.canvas.moveto(self.id, e.x - 50)

    def draw(self):
        pos = self.canvas.coords(self.id)

        if pos[0] <= 0:
            self.canvas.moveto(self.id, 0, 400)
        if pos[2] >= self.canvas_width:
            self.canvas.moveto(self.id, self.canvas_width - 100, 400)