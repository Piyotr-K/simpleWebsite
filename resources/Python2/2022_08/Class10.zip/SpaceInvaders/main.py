import turtle as tl
import os
# Class10

root = tl.Screen()
root.bgcolor("black")
root.bgpic("./SpaceInvaders/imgs/skull_trumpet.png")
root.title("Space Invaders")

p_img = os.path.abspath("./SpaceInvaders/imgs/bruh.gif")
tl.register_shape(p_img)
player = tl.Turtle()
player.shape(p_img)

root.mainloop()

# Hw
# Required:
# Move turtle with arrow or WASD
# ok