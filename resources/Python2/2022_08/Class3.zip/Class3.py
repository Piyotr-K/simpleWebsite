class Employee():

    # Class variable
    num_employees : int = 0
    raise_amt = 1.05

    def __init__(self, fn, ln, pay) -> None:
        self.first = fn
        self.last = ln
        self.pay : float = pay
        self.email = f"{fn.lower()}{ln.lower()}@testmail.com"
        Employee.num_employees += 1
    
    # String representation of the class
    def __str__(self) -> str:
        return f"Employee named: {self.first} {self.last} \nPaid: ${round(self.pay, 2)}/hr \nEmail: {self.email}"
    
    def __repr__(self) -> str:
        return self.__str__()
    
    # An instance method
    def apply_raise(self) -> None:
        self.pay *= Employee.raise_amt

    @classmethod
    def inc_raise(cls) -> None:
        cls.raise_amt += 0.05
    
    @classmethod
    def from_string(cls, line : str):
        f, l, p = line.split(".")
        p = float(p)
        return cls(f, l, p)
    
    @staticmethod
    def is_weekday(day : int) -> bool:
        if day != 0 and day != 6:
            return True
        return False