import Class3 as C

# variableName = open("fileName", "r")
# data = variableName.readlines()
# data = variableName.read().splitlines()

# empList = []

# for i in range(50):
#     empList.append(C.Employee("x", "y", i))

# print(empList)

# print(C.Employee.num_employees)

# John.Doe.16
# Jane.Doe.15
# Jake.Jones.18

# e1 = C.Employee("John", "Doe", 16)
# print(e1)
# e2 = C.Employee("Nice", "Man", 15)
# e3 = C.Employee.from_string("Jake.Jones.18")
# print(C.Employee.is_weekday(0))
# for x in range(5):
#     e2.apply_raise()
# print(e2)

# C.Employee.inc_raise()

# e2.apply_raise()
# print(e2)