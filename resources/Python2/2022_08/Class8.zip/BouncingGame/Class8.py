import tkinter as tk
import BallGame as bg
import time as T

def move_up(e):
    canvas.move(text, 0, -2)

root = tk.Tk()
root.resizable(0,0) # cannot resize window
root.wm_attributes("-topmost", 1) # makes the window stay on top all the time

canvas = tk.Canvas(root, width=500, height=500)
canvas.pack()

text = canvas.create_text(250, 250, text="Moveable", font=("consolas", 20))

canvas.bind_all("w", move_up)
root.update()

ball = bg.Ball(canvas, "red")

# Hw
# Required:
# Spawn ball in random direction upon starting
# A reset button that puts the ball back at the start
# and gives it a random direction

while True:
    ball.draw()
    root.update_idletasks()
    root.update()
    T.sleep(0.01)