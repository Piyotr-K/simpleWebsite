import tkinter as tk

class Ball():
    def __init__(self, canvas, colour):
        self.canvas : tk.Canvas = canvas
        self.id = self.canvas.create_oval(10,10,25,25,fill=colour)
        self.canvas.move(self.id, 245, 100)
        self.x_vel = 1
        self.y_vel = 1
        self.canvas_height = self.canvas.winfo_height()
        self.canvas_width = self.canvas.winfo_width()
    
    def draw(self):
        self.canvas.move(self.id, self.x_vel, self.y_vel)

        pos = self.canvas.coords(self.id)

        # pos = [x1, y1, x2, y2]
        if pos[1] <= 0:
            self.y_vel = 1
        if pos[3] >= self.canvas_height:
            self.y_vel = -1
        if pos[0] <= 0:
            self.x_vel = 1
        if pos[2] >= self.canvas_width:
            self.x_vel = -1
