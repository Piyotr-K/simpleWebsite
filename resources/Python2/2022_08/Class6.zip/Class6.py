import tkinter as T

def btnPressNum(num):
    global eq, equation
    eq = eq + str(num)
    equation.set(eq)

def btnPressOp(op):
    global eq, equation

    if op == "=":
        total = str(eval(eq))
        equation.set(total)
        eq = total
    else:
        eq = eq + str(op)
        equation.set(eq)
# ACTUAL equation
eq = ''

root = T.Tk()
root.geometry("250x300")
# display equation
equation = T.StringVar()
calc = T.Label(root, textvariable=equation, height=2,width=30)
equation.set("23+45")
eq = "23+45"
calc.grid(row=0, columnspan=4, sticky="ew")

btnList = []
for i in range(10):
    btnList.append(T.Button(root, text=str(i), command=(lambda i=i:btnPressNum(i))))

btnList[1].grid(row=1, column=0, sticky="ew", ipadx=5, ipady=5)
btnList[2].grid(row=1, column=1, sticky="ew", padx=5, pady=5)
btnList[3].grid(row=1, column=2, sticky="ew")
btnList[4].grid(row=2, column=0, sticky="ew")
btnList[5].grid(row=2, column=1, sticky="ew")
btnList[6].grid(row=2, column=2, sticky="ew")
btnList[7].grid(row=3, column=0, sticky="ew")
btnList[8].grid(row=3, column=1, sticky="ew")
btnList[9].grid(row=3, column=2, sticky="ew")
btnList[0].grid(row=4, column=1, sticky="ew")

plusBtn = T.Button(root, text="+", command=lambda:btnPressOp("+"))
minusBtn = T.Button(root, text="-", command=lambda:btnPressOp("-"))

equals = T.Button(root, text="=", command=lambda:btnPressOp("="))

plusBtn.grid(row = 1, column=3, sticky="ew")
minusBtn.grid(row = 2, column=3, sticky="ew")

equals.grid(row=4, column=2, sticky="ew")

# eval("equation") -> evalutes an equation and returns the output
# print(eval("23 + 45"))

root.mainloop()

# Required:
# Implement * and / and C for clear
# They should do as they should
# Play with the padding for different layouts