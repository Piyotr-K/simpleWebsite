import tkinter as T
import Class3 as C

root = T.Tk()

topFrame = T.Frame(root)
topFrame.pack(side=T.TOP)

# nice : C.Employee = C.Employee("")

# botFrame = T.Frame(root)
# botFrame.pack(side=T.BOTTOM)

lbl = T.Label(topFrame, text="")

btn1 = T.Button(topFrame, text="Click This Button", fg="green")
btn1.pack(side=T.LEFT)
btn2 = T.Button(topFrame, text="Click This Button", fg="red")
btn2.pack(side=T.LEFT)

# btn3 = T.Button(botFrame, text="Wow bottom buttons!", fg="red")
# btn3.pack(side=T.LEFT)
# btn4 = T.Button(botFrame, text="Wow bottom buttons!", fg="green")
# btn4.pack(side=T.LEFT)

root.mainloop()

# Required:
# Display 2 new employees in the frame when the user clicks
# on any of the two buttons
# Challenge:
# Display all the employees from the employees.txt
# in the topFrame